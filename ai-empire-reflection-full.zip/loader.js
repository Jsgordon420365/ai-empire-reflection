
window.addEventListener("load", function () {
  const audio = new Audio('assets/audio/intro_theme.mp3');
  audio.loop = true;
  audio.volume = 0.5;
  audio.play().catch(err => console.log("Audio autoplay blocked."));
});
